"""
challenger: dukpanahavad
purpos: usage of print, comment and docstring is same file.
"""
#this is the head haha
print("Hello World!")
#here is the body woohoo
print("I know how to print,\nI know how to create comments,\nI know how to create docstrings,")
#yess this will be the footer
print("Python is very easy, I am ready for the next challenges!")