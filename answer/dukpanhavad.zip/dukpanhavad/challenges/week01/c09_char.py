"""
challenger: dukpanahavad
purpos: first and last index of string
"""
#promt for user input
inputed_info = input("Enter something: ")
#show first and last index of inputed string
print("["+ inputed_info[0] +"]["+ inputed_info[-1] +"]" if inputed_info else "[][]")