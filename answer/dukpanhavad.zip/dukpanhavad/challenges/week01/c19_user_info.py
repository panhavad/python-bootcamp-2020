"""
challenger: dukpanahavad
"""
firstname = input("Enter your first name: ")
lastname = input("Enter your last name: ")
email = input("Enter your email: ")
print("FIRST NAME =", firstname, "\nLAST NAME =", lastname, "\nEMAIL =", email)