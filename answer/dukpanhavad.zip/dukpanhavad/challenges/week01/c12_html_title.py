"""
challenger: dukpanahavad
purpos: print html h1 title base on input
"""
print("<h1>" + input("Enter a title: ") + "</h1>")