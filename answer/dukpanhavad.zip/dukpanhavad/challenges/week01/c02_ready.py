#using builtin print function to print Ready to work!
print("Ready to work!")