"""
challenger: dukpanahavad
purpos: split input word by space
"""
#woohhaa online haha
print(input("Enter a text: ").split(" "))
