"""
challenger: dukpanahavad
purpos: get input and display
"""
#only one line woohoo haha
print(input("Type something: ")) #TODO: done this programe with zero line haha