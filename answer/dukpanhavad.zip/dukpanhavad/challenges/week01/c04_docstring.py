"""
challenger: dukpanahavad
purpos: using builtin print function to print Too Easy!
"""
print("Too Easy!")