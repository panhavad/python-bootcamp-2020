#print hello world using builtin print function
print("Hello World!")