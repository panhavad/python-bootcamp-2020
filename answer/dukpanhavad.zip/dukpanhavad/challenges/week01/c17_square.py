"""
challenger: dukpanahavad
purpos: quare the input integer
"""
#woohhaa online haha
print(int(input("Enter a number: "))**2)
